-- AlterTable
ALTER TABLE "items" ADD COLUMN     "sellingPriceWIC" DECIMAL(15,4);
