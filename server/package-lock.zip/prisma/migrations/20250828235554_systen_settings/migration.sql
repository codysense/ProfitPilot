-- AlterTable
ALTER TABLE "system_settings" ADD COLUMN     "category" TEXT;
